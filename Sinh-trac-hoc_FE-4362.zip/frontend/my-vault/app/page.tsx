"use client";
import { useState, useEffect } from 'react';
import LoginScreen from '../components/LoginScreen';
import VaultGallery from '../components/VaultGallery';

export default function Home() {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [showVideo, setShowVideo] = useState(false); 
  const [masterKey, setMasterKey] = useState('');

  // 1. KHÔI PHỤC PHIÊN ĐĂNG NHẬP KHI BẤM F5 (RELOAD)
  useEffect(() => {
    const savedKey = sessionStorage.getItem('e2ee_master_key');
    if (savedKey) {
      setMasterKey(savedKey);
      setIsUnlocked(true); // Vào thẳng két, không cần xem lại video
    }
  }, []);

  // 2. LƯU CHÌA KHÓA VÀ BẬT VIDEO KHI ĐĂNG NHẬP THÀNH CÔNG LẦN ĐẦU
  const handleUnlockSuccess = (key: string) => {
    sessionStorage.setItem('e2ee_master_key', key);
    setMasterKey(key);
    setShowVideo(true); 
  };

  // 3. XÓA CHÌA KHÓA KHI KHÓA KÉT
  const handleLock = () => {
    sessionStorage.removeItem('e2ee_master_key');
    setIsUnlocked(false);
    setMasterKey('');
  };

  return (
    // Đổi nền thành màu đen xanh sâu thẳm giống thiết kế
    <main className="min-h-screen bg-[#0A0D14] text-slate-200 font-sans selection:bg-indigo-500/30">
      
      {showVideo && (
        <div className="fixed inset-0 z-[100] bg-black flex items-center justify-center animate-in fade-in duration-500">
          <video 
            src="/mo-ket.mp4" 
            autoPlay 
            playsInline
            onEnded={() => {
              setShowVideo(false); 
              setIsUnlocked(true); 
            }}
            className="w-full h-full object-cover"
          />
          <button 
            onClick={() => { setShowVideo(false); setIsUnlocked(true); }}
            className="absolute top-8 right-8 px-4 py-2 bg-black/60 hover:bg-black/90 text-white text-sm font-bold rounded-lg backdrop-blur-md border border-white/10 shadow-lg transition-all active:scale-95 z-[101]"
          >
            Bỏ qua &gt;&gt;
          </button>
        </div>
      )}

      {/* Rẽ nhánh UI: Nếu chưa đăng nhập thì hiện khối giữa màn hình, nếu vào két thì bung full màn hình */}
      {!isUnlocked && !showVideo ? (
        <div className="max-w-6xl mx-auto p-4 md:p-8 flex items-center justify-center min-h-screen">
          <LoginScreen onUnlockSuccess={handleUnlockSuccess} />
        </div>
      ) : isUnlocked && !showVideo ? (
        <VaultGallery 
          masterKeyString={masterKey} 
          onLock={handleLock} 
        />
      ) : null}
    </main>
  );
}