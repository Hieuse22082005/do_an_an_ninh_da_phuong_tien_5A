"use client";
import { useState, useEffect, useRef } from 'react';
import CryptoJS from 'crypto-js';
import { encryptFile, decryptFile } from '../utils/cryptoService';
import { generateBlurredThumbnail } from '../utils/mediaHelper';
import type { SecureImage } from '../types';
import { startRegistration } from '@simplewebauthn/browser';
import { ShieldCheck } from "lucide-react";
import { supabase } from '@/lib/supabaseClient';

const AUTO_LOCK_TIMEOUT = 3 * 60 * 1000;
interface TrashItem { filename: string; deletedAt: number; }
interface ExtendedSecureImage extends SecureImage { originalThumb?: string | null; }

export default function VaultGallery({ masterKeyString, onLock }: { masterKeyString: string, onLock: () => void }) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [tappedCard, setTappedCard] = useState<string | null>(null);

  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [images, setImages] = useState<ExtendedSecureImage[]>([]);
  const [status, setStatus] = useState<string>('');
  const [isUploadPrivate, setIsUploadPrivate] = useState<boolean>(false);
  const [uploadLevel2Key, setUploadLevel2Key] = useState<string>('');
  
  const [viewingImage, setViewingImage] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState(''); 
  const [activeTab, setActiveTab] = useState<string>('all'); 
  const [favorites, setFavorites] = useState<string[]>([]); 
  const [trashList, setTrashList] = useState<TrashItem[]>([]); 
  const [collections, setCollections] = useState<Record<string, string[]>>({}); 
  const [aliases, setAliases] = useState<Record<string, string>>({});
  const [vaultName, setVaultName] = useState<string>('TEAM 5');
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [showColMenuFor, setShowColMenuFor] = useState<string | null>(null);

  const [promptData, setPromptData] = useState<{
    isOpen: boolean; message: string; isPassword: boolean; defaultValue: string; resolve: ((value: string | null) => void) | null;
  }>({ isOpen: false, message: '', isPassword: false, defaultValue: '', resolve: null });
  const [promptInput, setPromptInput] = useState('');
  const [showPasswordToggle, setShowPasswordToggle] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const walletAddress = CryptoJS.SHA256(masterKeyString).toString();

  useEffect(() => {
    const currentDeviceId = localStorage.getItem('device_id'); 
    const currentWalletAddress = localStorage.getItem('wallet_address');

    if (!currentDeviceId || !currentWalletAddress) return;

    const channel = supabase
      .channel('vault_device_tracker')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'passkeys', 
          filter: `wallet_address=eq.${currentWalletAddress}`, 
        },
        (payload) => {
          if (payload.new.active_device_id && payload.new.active_device_id !== currentDeviceId) {
            sessionStorage.removeItem('e2ee_master_key'); 
            localStorage.clear(); 
            
            alert('Cảnh báo: Tài khoản đã được truy cập từ thiết bị khác. Bạn đã bị đăng xuất!');
            window.location.reload(); 
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const showStatus = (msg: string, timeout = 3000) => {
    setStatus(msg);
    if (timeout > 0) setTimeout(() => setStatus(''), timeout);
  };

  const askPrompt = (message: string, isPassword = false, defaultValue = ""): Promise<string | null> => {
    setPromptInput(defaultValue);
    setShowPasswordToggle(!isPassword); 
    return new Promise((resolve) => {
      setPromptData({ isOpen: true, message, isPassword, defaultValue, resolve });
    });
  };

  useEffect(() => {
    const savedTheme = localStorage.getItem('vault_theme');
    if (savedTheme) setTheme(savedTheme as 'dark' | 'light');
    const savedName = localStorage.getItem(`vault_name_${walletAddress}`);
    if (savedName) setVaultName(savedName);
    const savedFavs = localStorage.getItem(`favs_${walletAddress}`);
    if (savedFavs) setFavorites(JSON.parse(savedFavs));
    const savedCols = localStorage.getItem(`cols_${walletAddress}`);
    if (savedCols) setCollections(JSON.parse(savedCols));
    const savedAliases = localStorage.getItem(`aliases_${walletAddress}`);
    if (savedAliases) setAliases(JSON.parse(savedAliases));

    const savedTrash = localStorage.getItem(`trash_${walletAddress}`);
    if (savedTrash) {
      const parsedTrash: TrashItem[] = JSON.parse(savedTrash);
      const now = Date.now();
      const validTrash = parsedTrash.filter(t => now - t.deletedAt < 30 * 24 * 60 * 60 * 1000);
      setTrashList(validTrash);
      if (validTrash.length !== parsedTrash.length) localStorage.setItem(`trash_${walletAddress}`, JSON.stringify(validTrash));
    }
  }, [walletAddress]);

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    localStorage.setItem('vault_theme', newTheme);
  };

  const fetchImages = async () => {
    try {
      const res = await fetch(`https://sinh-trac-hoc-be.onrender.com/photos?wallet_address=${walletAddress}`);
      const data = await res.json();
      const processedImages: ExtendedSecureImage[] = [];
      for (const item of data.photos) {
        if (item.is_private) {
          let decryptedThumb = null;
          if (item.thumbnail) {
            try { decryptedThumb = CryptoJS.AES.decrypt(item.thumbnail, masterKeyString).toString(CryptoJS.enc.Utf8); } catch(e) {}
          }
          processedImages.push({ filename: item.filename, src: null, thumb: decryptedThumb, originalThumb: decryptedThumb, is_private: true });
        } else {
          try {
            const { data: { publicUrl } } = supabase.storage.from('vault_images').getPublicUrl(item.filename);
            
            const fileRes = await fetch(publicUrl);
            if (fileRes.ok) {
              const blob = await fileRes.blob();
              const base64Data = await decryptFile(blob, masterKeyString);
              processedImages.push({ filename: item.filename, src: base64Data, thumb: null, originalThumb: null, is_private: false });
            }
          } catch (err) {}
        }
      }
      setImages(processedImages);
    } catch (error) {}
  };

  useEffect(() => { fetchImages(); }, []);

  useEffect(() => {
    let timeoutId: ReturnType<typeof setTimeout>;
    const resetTimer = () => { clearTimeout(timeoutId); timeoutId = setTimeout(() => { onLock(); }, AUTO_LOCK_TIMEOUT); };
    resetTimer(); 
    window.addEventListener('mousemove', resetTimer); window.addEventListener('keydown', resetTimer); window.addEventListener('click', resetTimer);
    return () => { clearTimeout(timeoutId); window.removeEventListener('mousemove', resetTimer); window.removeEventListener('keydown', resetTimer); window.removeEventListener('click', resetTimer); };
  }, [onLock]);

  const handleRename = async (filename: string, currentName: string) => {
    const newName = await askPrompt("Nhập tên hiển thị mới cho file này:", false, currentName);
    if (newName !== null && newName.trim() !== "") {
      let finalNewName = newName.trim();
      
      if (currentName.includes('.') && !finalNewName.includes('.')) {
        finalNewName += currentName.substring(currentName.lastIndexOf('.'));
      }
      
      const updatedAliases = { ...aliases, [filename]: finalNewName };
      setAliases(updatedAliases);
      localStorage.setItem(`aliases_${walletAddress}`, JSON.stringify(updatedAliases));
      showStatus("✅ Đã cập nhật tên hiển thị!");
    }
  };

  const handleCreateCollection = async () => {
    const name = await askPrompt("Nhập tên Bộ sưu tập mới:");
    if (name && !collections[name]) {
      const newCols = { ...collections, [name]: [] };
      setCollections(newCols);
      localStorage.setItem(`cols_${walletAddress}`, JSON.stringify(newCols));
      showStatus(`✅ Đã tạo: ${name}`);
    }
  };

  const handleDeleteCollection = (colName: string) => {
    if (window.confirm(`Xóa bộ sưu tập "${colName}"? (Ảnh gốc vẫn được giữ lại)`)) {
      const newCols = { ...collections };
      delete newCols[colName];
      setCollections(newCols);
      localStorage.setItem(`cols_${walletAddress}`, JSON.stringify(newCols));
      if (activeTab === colName) setActiveTab('all');
    }
  };

  const handleRemoveFromCollection = (colName: string, filename: string) => {
    const updated = { ...collections, [colName]: collections[colName].filter(f => f !== filename) };
    setCollections(updated);
    localStorage.setItem(`cols_${walletAddress}`, JSON.stringify(updated));
  };

  const executeAddToCollection = (colName: string) => {
    if (showColMenuFor === 'batch') {
      const updated = { ...collections, [colName]: [...new Set([...collections[colName], ...selectedFiles])] };
      setCollections(updated);
      localStorage.setItem(`cols_${walletAddress}`, JSON.stringify(updated));
      setSelectedFiles([]);
      showStatus(`✅ Đã thêm loạt ảnh vào ${colName}`);
    } else if (showColMenuFor) {
      const updated = { ...collections, [colName]: [...new Set([...collections[colName], showColMenuFor])] };
      setCollections(updated);
      localStorage.setItem(`cols_${walletAddress}`, JSON.stringify(updated));
      showStatus(`✅ Đã thêm vào ${colName}`);
    }
    setShowColMenuFor(null);
  };

  const handleRegisterFaceID = async () => {
    const customName = await askPrompt("Nhập tên hiển thị cho Két sắt này:", false, vaultName);
    if (customName === null) return;
    const finalName = customName || vaultName;

    showStatus("Đang bật Cảm biến sinh trắc học...", 0);
    try {
      const resOpt = await fetch('https://sinh-trac-hoc-be.onrender.com/webauthn/register/generate', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ wallet_address: walletAddress, vault_name: finalName }) });
      const options = await resOpt.json();
      
      const attResp = await startRegistration({ optionsJSON: options }); 
      
      const resVerify = await fetch('https://sinh-trac-hoc-be.onrender.com/webauthn/register/verify', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ wallet_address: walletAddress, credential: attResp }) });
      if (resVerify.ok) {
        localStorage.setItem(`vault_key_${walletAddress}`, masterKeyString);
        localStorage.setItem(`vault_name_${walletAddress}`, finalName);
        setVaultName(finalName);
        showStatus(`✅ Đã thêm FaceID!`);
      }
    } catch (error) { showStatus("❌ Hủy đăng ký."); }
  };

  const handleRegisterEmail = async () => {
    showStatus("Đang kiểm tra dữ liệu Két...", 0);
    
    try {
      const { data: existing, error: checkError } = await supabase
        .from('passkeys')
        .select('recovery_email')
        .eq('wallet_address', walletAddress)
        .maybeSingle();

      if (checkError) throw checkError;

      if (existing && existing.recovery_email) {
        const confirmUpdate = window.confirm(`⚠️ Két sắt này đang liên kết với Email: ${existing.recovery_email}\n\nBạn có muốn đổi sang Email khác không?`);
        if (!confirmUpdate) {
          showStatus("Đã hủy thao tác đổi email.", 2000);
          return;
        }

        showStatus("Đang gửi mã OTP đến email cũ...", 0);
        
        try {
           const sendRes = await fetch('https://sinh-trac-hoc-be.onrender.com/request-otp', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ email: existing.recovery_email, wallet_address: walletAddress }) 
           });
           if (!sendRes.ok) throw new Error("Gửi OTP thất bại");
        } catch(e) {
           showStatus("❌ Không thể kết nối tới máy chủ để gửi OTP!"); 
           return;
        }

        const otp = await askPrompt(`Nhập mã OTP 6 số vừa được gửi đến email ${existing.recovery_email}:`, false);
        if (!otp) return;

        showStatus("Đang xác thực OTP...", 0);
        
        const verifyRes = await fetch('https://sinh-trac-hoc-be.onrender.com/verify-otp', {
           method: 'POST',
           headers: { 'Content-Type': 'application/json' },
           body: JSON.stringify({ email: existing.recovery_email, otp_code: otp.trim(), wallet_address: walletAddress })
        });

        if (!verifyRes.ok) {
           showStatus("❌ Mã OTP không chính xác hoặc đã hết hạn!");
           return;
        }
      }

      const messagePrompt = existing?.recovery_email 
        ? "Nhập địa chỉ Email MỚI muốn thay đổi:" 
        : "Tạo liên kết: Nhập địa chỉ Email bảo mật của bạn (Dùng để nhận OTP khôi phục):";

      const newEmail = await askPrompt(messagePrompt, false);
      if (!newEmail) return;

      showStatus("Đang lưu email...", 0);
      const currentDeviceId = localStorage.getItem('device_id');

      const { error } = await supabase
        .from('passkeys')
        .upsert({ 
          wallet_address: walletAddress, 
          recovery_email: newEmail.trim(),
          active_device_id: currentDeviceId
        }, { 
          onConflict: 'wallet_address'
        });

      if (error) {
        showStatus(`❌ Lỗi hệ thống: ${error.message}`);
      } else {
        showStatus("✅ Đã cập nhật Email bảo mật thành công!");
      }
    } catch (err) {
      console.error("Lỗi kiểm tra két:", err);
      showStatus("❌ Không thể kết nối tới cơ sở dữ liệu!");
    }
  };

  const uploadSingleFile = async (file: File, baseName: string) => {
    try {
      const keyToUse = isUploadPrivate ? uploadLevel2Key : masterKeyString;
      
      showStatus(`Đang mã hóa ${file.name}... (Sẽ hơi lâu vì bảo mật E2EE)`, 0);
      const encryptedBlob = await encryptFile(file, keyToUse);
      let encryptedThumb = '';
      
      if (isUploadPrivate) {
        const isImage = file.type.startsWith('image/') || /\.(jpg|jpeg|png|gif|webp|heic|bmp)$/i.test(file.name);
        if (isImage) {
          try {
            const thumbBase64 = await generateBlurredThumbnail(file);
            if (thumbBase64) encryptedThumb = CryptoJS.AES.encrypt(thumbBase64, masterKeyString).toString();
          } catch(err) {
            console.log("Bỏ qua tạo thumbnail");
          }
        }
      }
      
      let finalFileName = baseName;
      if (!finalFileName.includes('.')) {
        const ext = file.name.substring(file.name.lastIndexOf('.'));
        finalFileName += ext;
      }

      const formData = new FormData();
      formData.append('file', encryptedBlob, finalFileName);
      formData.append('is_private', isUploadPrivate ? 'true' : 'false');
      formData.append('thumbnail', encryptedThumb);
      formData.append('wallet_address', walletAddress); 
      
      showStatus(`ĐANG TẢI LÊN ${finalFileName.toUpperCase()}...`, 0);
      
      const response = await fetch('https://sinh-trac-hoc-be.onrender.com/upload', { method: 'POST', body: formData });
      
      if (response.ok) { 
        try {
           const resData = await response.json();
           const savedFilename = resData.filename || resData.file_name;
           if (savedFilename) {
               setAliases(prev => {
                 const newAliases = { ...prev, [savedFilename]: finalFileName };
                 localStorage.setItem(`aliases_${walletAddress}`, JSON.stringify(newAliases));
                 return newAliases;
               });
           }
        } catch(err) {}
        return true;
      } else {
        // NẾU SERVER TỪ CHỐI FILE (Quá giới hạn 50MB, Timeout...)
        const errData = await response.json().catch(() => ({}));
        console.error("Lỗi Upload:", response.status, errData);
        showStatus(`❌ Lỗi tải lên: File quá nặng hoặc Server từ chối!`, 5000);
        return false;
      }
    } catch (error) { 
      // NẾU MẤT MẠNG HOẶC TRÌNH DUYỆT TRÀN RAM DO FILE QUÁ TO
      console.error("Lỗi Network/Mã hóa:", error);
      showStatus(`❌ Lỗi: File quá lớn khiến trình duyệt quá tải hoặc rớt mạng!`, 5000);
      return false;
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    if (isUploadPrivate && !uploadLevel2Key) {
      alert("Vui lòng nhập mật khẩu tuyệt mật bên dưới trước khi chọn file!");
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    const totalFiles = files.length;

    if (totalFiles === 1) {
      const file = files[0];
      
      // THÊM TÍNH NĂNG CẢNH BÁO DUNG LƯỢNG (Giới hạn Supabase thường là 50MB)
      // File mã hóa sẽ nặng thêm 30%, nên mình cảnh báo nếu file gốc > 30MB
      if (file.size > 30 * 1024 * 1024) { 
         const confirmLarge = window.confirm(`⚠️ Video này rất nặng (${(file.size / 1024 / 1024).toFixed(1)}MB).\n\nQuá trình mã hóa sẽ tốn nhiều RAM và Server miễn phí có thể từ chối tải lên. Bạn vẫn muốn thử chứ?`);
         if (!confirmLarge) {
            if (fileInputRef.current) fileInputRef.current.value = '';
            return;
         }
      }

      const userInput = await askPrompt("Nhập tên hiển thị cho file (Hoặc để trống để dùng tên gốc):", false, file.name);
      if (userInput === null) {
        if (fileInputRef.current) fileInputRef.current.value = '';
        return; 
      }
      
      const isSuccess = await uploadSingleFile(file, userInput.trim() || file.name);
      if (isSuccess) {
         showStatus("✅ Đã niêm phong!"); 
         fetchImages();
      }
    } 
    else {
      let successCount = 0;
      showStatus(`Đang chuẩn bị tải lên ${totalFiles} file...`, 0);
      
      for (let i = 0; i < totalFiles; i++) {
        const file = files[i];
        const isSuccess = await uploadSingleFile(file, file.name);
        if (isSuccess) successCount++;
      }
      
      if (successCount > 0) {
         showStatus(`✅ Đã niêm phong thành công ${successCount}/${totalFiles} file!`, 5000);
         fetchImages();
      } else {
         showStatus(`❌ Thất bại: Không có file nào được tải lên.`, 5000);
      }
    }
    
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleChangePrivacy = async (item: ExtendedSecureImage, makePrivate: boolean, newPassword?: string) => {
    try {
      showStatus("Đang xử lý...", 0);
      let fileObj: File;
      if (item.src) {
        const response = await fetch(item.src);
        const blobData = await response.blob();
        fileObj = new File([blobData], item.filename, { type: blobData.type });
      } else return alert("Hãy mở khóa ảnh này trước khi thay đổi trạng thái!");

      const keyToUse = makePrivate ? newPassword! : masterKeyString;
      const encryptedBlob = await encryptFile(fileObj, keyToUse);
      let encryptedThumb = '';
      
      if (makePrivate) {
        // CHỈ tạo ảnh mờ khi CHẮC CHẮN nó là ẢNH
        const isImage = fileObj.type.startsWith('image/') || /\.(jpg|jpeg|png|gif|webp|heic|bmp)$/i.test(item.filename);
        if (isImage) {
           try {
             const thumbBase64 = await generateBlurredThumbnail(fileObj);
             if(thumbBase64) encryptedThumb = CryptoJS.AES.encrypt(thumbBase64, masterKeyString).toString();
           } catch(err) {
             console.log("Bỏ qua tạo thumbnail");
           }
        }
      }
      
      const formData = new FormData();
      formData.append('file', encryptedBlob, item.filename);
      formData.append('is_private', makePrivate ? 'true' : 'false');
      formData.append('thumbnail', encryptedThumb);
      formData.append('wallet_address', walletAddress); 
      
      const response = await fetch('https://sinh-trac-hoc-be.onrender.com/upload', { method: 'POST', body: formData });
      if (response.ok) {
        const resData = await response.json();
        const newFilename = resData.filename || resData.file_name;
        
        const currentAlias = aliases[item.filename] || item.filename;
        if (newFilename) {
           const newAliases: Record<string, string> = { ...aliases, [newFilename]: currentAlias };
           delete newAliases[item.filename];
           setAliases(newAliases);
           localStorage.setItem(`aliases_${walletAddress}`, JSON.stringify(newAliases));
        }

        const sysDeletePass = process.env.NEXT_PUBLIC_DELETE_PASSWORD || '22082005';
        await fetch(`https://sinh-trac-hoc-be.onrender.com/delete/${item.filename}?delete_pass=${sysDeletePass}`, { method: 'DELETE' });
        
        fetchImages(); 
        showStatus(makePrivate ? "✅ Đã khóa tuyệt mật!" : "✅ Đã chuyển thành công khai!");
      } else {
        throw new Error("Upload failed");
      }
    } catch (error) { showStatus("❌ Lỗi chuyển đổi!"); }
  };

  const handleUnlockSinglePrivate = async (filename: string, specificKey: string) => {
    showStatus(`Đang giải mã...`, 0);
    try {
      const { data: { publicUrl } } = supabase.storage.from('vault_images').getPublicUrl(filename);
      const fileRes = await fetch(publicUrl);
      const blob = await fileRes.blob();
      
      const base64Data = await decryptFile(blob, specificKey);
      setImages(prev => prev.map(img => img.filename === filename ? { ...img, src: base64Data, originalThumb: img.thumb, thumb: null } : img));
      showStatus("✅ Mở khóa thành công!");
    } catch (error) { showStatus("❌ Sai mật khẩu!"); }
  };

  const handleRelockSingle = (filename: string) => {
    setImages(prev => prev.map(img => img.filename === filename ? { ...img, src: null, thumb: img.originalThumb ?? null } : img));
    showStatus("🔒 Đã khóa lại an toàn.");
  };

  const toggleFavorite = (filename: string) => {
    const newFavs = favorites.includes(filename) ? favorites.filter(f => f !== filename) : [...favorites, filename];
    setFavorites(newFavs);
    localStorage.setItem(`favs_${walletAddress}`, JSON.stringify(newFavs));
  };

  const handleSoftDelete = async (filename: string) => {
    const pass = await askPrompt("🔒 NHẬP MẬT KHẨU HỆ THỐNG để chuyển file vào Thùng rác:", true);
    if (!pass) return;
    localStorage.setItem('sys_del_pass', pass); 
    const newTrash = [...trashList, { filename, deletedAt: Date.now() }];
    setTrashList(newTrash);
    localStorage.setItem(`trash_${walletAddress}`, JSON.stringify(newTrash));
    setFavorites(favorites.filter(f => f !== filename));
    localStorage.setItem(`favs_${walletAddress}`, JSON.stringify(favorites.filter(f => f !== filename)));
    showStatus("Đã chuyển vào Thùng rác.");
  };

  const handleRestore = (filename: string) => {
    const newTrash = trashList.filter(t => t.filename !== filename);
    setTrashList(newTrash);
    localStorage.setItem(`trash_${walletAddress}`, JSON.stringify(newTrash));
    showStatus("✅ Đã khôi phục.");
  };

  const handleHardDelete = async (filename: string) => {
    if (!window.confirm("⚠️ Xóa vĩnh viễn file này khỏi máy chủ? KHÔNG THỂ KHÔI PHỤC!")) return;
    let pass = localStorage.getItem('sys_del_pass') || await askPrompt("Nhập MẬT KHẨU HỆ THỐNG để xóa:", true);
    if (!pass) return;
    
    try {
      const response = await fetch(`https://sinh-trac-hoc-be.onrender.com/delete/${filename}?delete_pass=${encodeURIComponent(pass)}`, { method: 'DELETE' });
      
      if (response.ok) {
        localStorage.setItem('sys_del_pass', pass); 
        setImages(prev => prev.filter(img => img.filename !== filename));
        setTrashList(trashList.filter(t => t.filename !== filename));
        localStorage.setItem(`trash_${walletAddress}`, JSON.stringify(trashList.filter(t => t.filename !== filename)));
        showStatus("✅ Đã xóa vĩnh viễn!");
      } else {
        localStorage.removeItem('sys_del_pass'); 
        if (response.status === 403) {
          showStatus("❌ Sai mật khẩu hệ thống! Vui lòng thử lại.");
        } else {
          const errData = await response.json();
          alert(`LỖI MÁY CHỦ: ${errData.detail}`); 
          showStatus("❌ Lỗi hệ thống, xem thông báo!");
        }
      }
    } catch (error) {
      localStorage.removeItem('sys_del_pass');
      showStatus("❌ Không thể kết nối đến máy chủ Render!");
    }
  };

  const toggleSelectFile = (filename: string) => {
    setSelectedFiles(prev => prev.includes(filename) ? prev.filter(f => f !== filename) : [...prev, filename]);
  };

  const handleBatchDownload = () => {
    selectedFiles.forEach(filename => {
      const item = images.find(img => img.filename === filename);
      if (item && item.src) {
        const a = document.createElement('a'); a.href = item.src; a.download = `vault_${filename.replace('.enc', '')}`; a.click();
      }
    });
    setSelectedFiles([]);
  };

  const handleBatchDelete = async () => {
    if (activeTab === 'trash') {
      if (!window.confirm(`⚠️ CHẮC CHẮN TIÊU HỦY VĨNH VIỄN ${selectedFiles.length} FILE NÀY?`)) return;
      let pass = localStorage.getItem('sys_del_pass') || await askPrompt("Nhập MẬT KHẨU HỆ THỐNG để xóa:", true);
      if (!pass) return;
      showStatus(`Đang tiêu hủy ${selectedFiles.length} file...`, 0);
      
      let hasError = false;
      let lastErrorMessage = "";

      for (const filename of selectedFiles) {
        try {
          const response = await fetch(`https://sinh-trac-hoc-be.onrender.com/delete/${filename}?delete_pass=${encodeURIComponent(pass)}`, { method: 'DELETE' });
          if (response.ok) {
             setImages(prev => prev.filter(img => img.filename !== filename));
             setTrashList(prev => prev.filter(t => t.filename !== filename));
          } else {
             hasError = true;
             if (response.status === 403) {
               lastErrorMessage = "Sai mật khẩu hệ thống!";
             } else {
               const errData = await response.json();
               lastErrorMessage = `Lỗi Server: ${errData.detail}`;
             }
          }
        } catch (error) { 
           hasError = true; 
           lastErrorMessage = "Mất kết nối Server!";
        }
      }

      if (hasError) {
         localStorage.removeItem('sys_del_pass'); 
         alert(lastErrorMessage); 
         showStatus("❌ Có lỗi xảy ra khi tiêu hủy!");
      } else {
         localStorage.setItem('sys_del_pass', pass);
         setSelectedFiles([]);
         localStorage.setItem(`trash_${walletAddress}`, JSON.stringify(trashList.filter(t => !selectedFiles.includes(t.filename))));
         showStatus("✅ Đã tiêu hủy hàng loạt!");
      }
    } else {
      const pass = await askPrompt(`🔒 NHẬP MẬT KHẨU HỆ THỐNG để chuyển ${selectedFiles.length} file vào Thùng rác:`, true);
      if (!pass) return;
      localStorage.setItem('sys_del_pass', pass);
      const newTrash = [...trashList];
      for (const filename of selectedFiles) {
        if (!newTrash.some(t => t.filename === filename)) newTrash.push({ filename, deletedAt: Date.now() });
      }
      setTrashList(newTrash);
      localStorage.setItem(`trash_${walletAddress}`, JSON.stringify(newTrash));
      setSelectedFiles([]);
      showStatus("Đã chuyển loạt file vào Thùng rác.");
    }
  };

  const handleBatchRestore = () => {
    const newTrash = trashList.filter(t => !selectedFiles.includes(t.filename));
    setTrashList(newTrash);
    localStorage.setItem(`trash_${walletAddress}`, JSON.stringify(newTrash));
    setSelectedFiles([]);
    showStatus("✅ Đã khôi phục loạt file!");
  };

  const displayImages = images.filter(img => {
    const displayName = aliases[img.filename] || img.filename;
    if (searchQuery && !displayName.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    
    const isTrashed = trashList.some(t => t.filename === img.filename);
    if (activeTab === 'trash') return isTrashed;
    if (isTrashed) return false;
    if (activeTab === 'favorites') return favorites.includes(img.filename);
    if (activeTab !== 'all') return collections[activeTab]?.includes(img.filename);
    return true;
  });

  const isVideoFile = (item: SecureImage) => {
    if (item.src && item.src.startsWith('data:video')) return true;
    const displayName = aliases[item.filename] || item.filename;
    if (displayName.toLowerCase().match(/\.(mp4|webm|ogg|mov)$/)) return true;
    return false;
  };

  const isDark = theme === 'dark';
  const bgMainColor = isDark ? '#080C14' : '#F2F5F9';
  const svgPatternColor = isDark ? '%23182033' : '%23e0e7ff';
  const textHeading = isDark ? 'text-white' : 'text-slate-900';
  const textSub = isDark ? 'text-slate-400' : 'text-slate-600';
  const sidebarBg = isDark ? 'bg-black/20 border-white/5' : 'bg-white/70 border-indigo-100 shadow-2xl';
  const headerBg = isDark ? 'bg-black/10 border-white/5' : 'bg-white/50 border-indigo-100 shadow-sm';
  const inputWrapper = isDark ? 'bg-white/5 border-white/5 focus-within:border-indigo-500/50' : 'bg-slate-100/80 border-slate-200 focus-within:border-indigo-400';
  const inputText = isDark ? 'text-slate-300 placeholder:text-slate-600' : 'text-slate-800 placeholder:text-slate-400';
  const cardBg = isDark ? 'bg-black/40 border-white/5 shadow-black/50' : 'bg-white border-slate-200 shadow-indigo-900/10';
  const uploadBox = isDark ? 'bg-indigo-950/20 border-indigo-500/30 hover:border-indigo-500/60' : 'bg-indigo-50/50 border-indigo-200 hover:border-indigo-400 shadow-inner';

  return (
    <div className={`w-screen h-screen flex font-sans overflow-hidden animate-in fade-in duration-500 relative transition-colors duration-700 ${isDark ? 'bg-[#080C14]' : 'bg-[#F2F5F9]'}`}>
      <div className="absolute inset-0 z-0 pointer-events-none transition-opacity duration-700 opacity-60"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='103.923' viewBox='0 0 60 103.923' xmlns='http://www.w3.org/2000/svg'%3E%3Cg stroke='${svgPatternColor}' stroke-width='1' fill='none' fill-rule='evenodd'%3E%3Cpath d='M30 17.32L60 0v34.64L30 51.96 0 34.64V0l30 17.32zM30 86.6l30-17.32v34.64L30 121.24 0 103.92V69.28L30 86.6zM30 51.96v34.64M60 34.64v34.64M0 34.64v34.64'/%3E%3C/g%3E%3C/svg%3E")`,
          backgroundAttachment: 'fixed'
        }}
      ></div>

      <div className={`absolute top-[-20%] left-[-10%] w-[600px] h-[600px] rounded-full blur-[120px] pointer-events-none transition-colors duration-1000 z-0 ${isDark ? 'bg-indigo-900/20' : 'bg-blue-300/30'}`}></div>
      <div className={`absolute bottom-[-20%] right-[-10%] w-[800px] h-[800px] rounded-full blur-[140px] pointer-events-none transition-colors duration-1000 z-0 ${isDark ? 'bg-blue-900/15' : 'bg-indigo-300/20'}`}></div>

      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[9990] md:hidden transition-opacity" 
          onClick={() => setIsMobileMenuOpen(false)} 
        />
      )}

      <aside 
        className={`fixed inset-y-0 left-0 z-[9999] w-64 transform ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0 shrink-0 border-r flex flex-col pt-8 overflow-y-auto custom-scrollbar backdrop-blur-2xl transition-transform duration-300 ${sidebarBg}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-8 mb-6 flex items-center gap-3 cursor-pointer group active:scale-95 transition-transform" onClick={() => { setActiveTab('all'); setIsMobileMenuOpen(false); }}>
          <div className="flex items-center justify-center w-10 h-10 shrink-0 bg-gradient-to-br from-violet-600 to-indigo-600 rounded-full shadow-[0_0_15px_rgba(79,70,229,0.5)] group-hover:scale-110 group-hover:shadow-[0_0_20px_rgba(79,70,229,0.7)] transition-all duration-300">
            <ShieldCheck className="w-5 h-5 text-white" strokeWidth={2.5} />
          </div>
          <h1 className={`text-2xl font-extrabold tracking-tight truncate transition-colors ${textHeading}`}>
            {vaultName}
          </h1>
        </div>

        <div className="flex-1 px-4 pb-10 relative mt-2">
          <div className={`relative flex flex-col gap-5 border-l-8 ${isDark ? 'border-white' : 'border-[#1a1a1a]'} pl-5 ml-3`}>
            
            <div className="flex items-baseline gap-3 mb-2">
              <span className={`text-xl font-black underline underline-offset-4 ${isDark ? 'text-white' : 'text-[#1a1a1a]'}`}>01</span>
              <span className={`text-[11px] uppercase tracking-[0.2em] font-extrabold ${isDark ? 'text-white' : 'text-[#1a1a1a]'}`}>Menu Két Sắt</span>
            </div>

            <div className="flex flex-col gap-4 relative z-10">
              <button 
                onClick={(e) => { e.stopPropagation(); setActiveTab('all'); setIsMobileMenuOpen(false); }} 
                className="group flex items-center w-full cursor-pointer relative transition-transform duration-200 hover:translate-x-2"
              >
                <div className={`w-8 h-8 shrink-0 border-[3px] flex items-center justify-center mr-4 transition-all duration-300 ${activeTab === 'all' ? 'border-[#e63946] bg-[#e63946]' : (isDark ? 'border-white bg-transparent' : 'border-[#1a1a1a] bg-transparent')}`}>
                  <span className={`text-sm transition-transform duration-300 ${activeTab === 'all' ? 'scale-110' : 'grayscale opacity-60 group-hover:opacity-100 group-hover:grayscale-0'}`}>🖼️</span>
                </div>
                <span className={`text-[13px] md:text-[14px] font-black uppercase tracking-tight transition-colors duration-300 flex-1 text-left ${activeTab === 'all' ? 'text-[#e63946]' : (isDark ? 'text-white' : 'text-[#1a1a1a]')}`}>Tổng hợp ảnh</span>
                <span className={`text-xs font-mono opacity-60 font-bold ${activeTab === 'all' ? 'text-[#e63946]' : (isDark ? 'text-white' : 'text-[#1a1a1a]')}`}>{images.length - trashList.length}</span>
              </button>

              <button 
                onClick={(e) => { e.stopPropagation(); handleCreateCollection(); setIsMobileMenuOpen(false); }} 
                className="group flex items-center w-full cursor-pointer relative transition-transform duration-200 hover:translate-x-2"
              >
                <div className={`w-8 h-8 shrink-0 border-[3px] flex items-center justify-center mr-4 transition-all duration-300 group-hover:border-[#4a90e2] group-hover:bg-[#4a90e2] ${isDark ? 'border-white bg-transparent' : 'border-[#1a1a1a] bg-transparent'}`}>
                  <span className="text-sm transition-transform duration-300 grayscale opacity-60 group-hover:opacity-100 group-hover:grayscale-0 group-hover:scale-110">➕</span>
                </div>
                <span className={`text-[13px] md:text-[14px] font-black uppercase tracking-tight transition-colors duration-300 flex-1 text-left ${isDark ? 'text-slate-400 group-hover:text-[#4a90e2]' : 'text-slate-500 group-hover:text-[#4a90e2]'}`}>Tạo bộ sưu tập</span>
              </button>

              {Object.keys(collections).map(col => (
                <div key={col} className="group/col relative flex items-center w-full transition-transform duration-200 hover:translate-x-2">
                    <button 
                      onClick={(e) => { e.stopPropagation(); setActiveTab(col); setIsMobileMenuOpen(false); }} 
                      className="flex items-center flex-1 cursor-pointer"
                    >
                      <div className={`w-8 h-8 shrink-0 border-[3px] flex items-center justify-center mr-4 transition-all duration-300 ${activeTab === col ? 'border-[#4a90e2] bg-[#4a90e2]' : (isDark ? 'border-white bg-transparent' : 'border-[#1a1a1a] bg-transparent')}`}>
                        <span className={`text-sm transition-transform duration-300 ${activeTab === col ? 'scale-110' : 'grayscale opacity-60 group-hover:opacity-100 group-hover:grayscale-0'}`}>📁</span>
                      </div>
                      <span className={`text-[13px] md:text-[14px] font-black uppercase tracking-tight transition-colors duration-300 flex-1 text-left truncate pr-2 ${activeTab === col ? 'text-[#4a90e2]' : (isDark ? 'text-white' : 'text-[#1a1a1a]')}`}>{col}</span>
                    </button>
                    <span className={`text-xs font-mono opacity-60 font-bold px-2 ${activeTab === col ? 'text-[#4a90e2]' : (isDark ? 'text-white' : 'text-[#1a1a1a]')}`}>{collections[col].length}</span>
                    <button onClick={(e) => { e.stopPropagation(); handleDeleteCollection(col); }} className="opacity-0 group-hover/col:opacity-100 px-2 py-1 text-slate-400 hover:text-rose-500 active:scale-90 transition-all font-bold" title="Xóa BST">✖</button>
                </div>
              ))}

              <button 
                onClick={(e) => { e.stopPropagation(); setActiveTab('favorites'); setIsMobileMenuOpen(false); }} 
                className="group flex items-center w-full cursor-pointer relative transition-transform duration-200 hover:translate-x-2 mt-4"
              >
                <div className={`w-8 h-8 shrink-0 border-[3px] flex items-center justify-center mr-4 transition-all duration-300 ${activeTab === 'favorites' ? 'border-[#fcbf49] bg-[#fcbf49]' : (isDark ? 'border-white bg-transparent' : 'border-[#1a1a1a] bg-transparent')}`}>
                  <span className={`text-sm transition-transform duration-300 ${activeTab === 'favorites' ? 'scale-110' : 'grayscale opacity-60 group-hover:opacity-100 group-hover:grayscale-0'}`}>❤️</span>
                </div>
                <span className={`text-[13px] md:text-[14px] font-black uppercase tracking-tight transition-colors duration-300 flex-1 text-left ${activeTab === 'favorites' ? 'text-[#fcbf49]' : (isDark ? 'text-white' : 'text-[#1a1a1a]')}`}>Yêu thích</span>
                <span className={`text-xs font-mono opacity-60 font-bold ${activeTab === 'favorites' ? 'text-[#fcbf49]' : (isDark ? 'text-white' : 'text-[#1a1a1a]')}`}>{favorites.length}</span>
              </button>

              <button 
                onClick={(e) => { e.stopPropagation(); setActiveTab('trash'); setIsMobileMenuOpen(false); }} 
                className="group flex items-center w-full cursor-pointer relative transition-transform duration-200 hover:translate-x-2"
              >
                <div className={`w-8 h-8 shrink-0 border-[3px] flex items-center justify-center mr-4 transition-all duration-300 ${activeTab === 'trash' ? 'border-[#ef476f] bg-[#ef476f]' : (isDark ? 'border-white bg-transparent' : 'border-[#1a1a1a] bg-transparent')}`}>
                  <span className={`text-sm transition-transform duration-300 ${activeTab === 'trash' ? 'scale-110' : 'grayscale opacity-60 group-hover:opacity-100 group-hover:grayscale-0'}`}>🗑️</span>
                </div>
                <span className={`text-[13px] md:text-[14px] font-black uppercase tracking-tight transition-colors duration-300 flex-1 text-left ${activeTab === 'trash' ? 'text-[#ef476f]' : (isDark ? 'text-white' : 'text-[#1a1a1a]')}`}>Thùng rác</span>
              </button>
            </div>
          </div>
        </div>
      </aside>

      <div className="relative z-10 flex w-full h-full flex-col md:flex-row">
        <main className="flex-1 flex flex-col relative h-screen w-full">
          <header className={`h-auto md:h-16 flex flex-col md:flex-row items-center justify-between px-4 md:px-8 py-3 md:py-0 shrink-0 border-b backdrop-blur-xl transition-colors duration-500 gap-3 md:gap-0 relative overflow-hidden ${headerBg}`}>
            
            <div className="flex items-center gap-3 w-full md:w-96 z-10">
              <button 
                onClick={() => setIsMobileMenuOpen(true)} 
                className={`md:hidden flex items-center justify-center p-2.5 rounded-xl border transition-all active:scale-95 shrink-0 z-50 ${isDark ? 'bg-white/5 border-white/10 text-slate-300' : 'bg-white border-slate-200 text-slate-600 shadow-sm'}`}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M4 6h16M4 12h16M4 18h16"></path></svg>
              </button>

              <div className={`flex-1 flex items-center gap-3 rounded-xl px-4 py-2 transition-all duration-300 ${inputWrapper}`}>
                <span className="text-slate-400 text-sm">🔍</span>
                <input type="text" placeholder="Tìm kỷ niệm (Theo tên gốc hoặc tên đã sửa)..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className={`bg-transparent border-none outline-none w-full text-sm focus:ring-0 ${inputText}`} />
              </div>
            </div>

            {status && (
              <div className="absolute inset-0 flex items-center justify-center z-0 pointer-events-none">
                <style dangerouslySetInnerHTML={{__html: `
                  @keyframes shine {
                    0% { background-position: -200% center; }
                    100% { background-position: 200% center; }
                  }
                  .animated-status-text {
                    background-size: 200% auto;
                    color: transparent;
                    -webkit-background-clip: text;
                    background-clip: text;
                    animation: shine 3s linear infinite;
                  }
                  .dark-mode-text {
                    background-image: linear-gradient(to right, #ffffff 40%, #475569 50%, #ffffff 60%);
                  }
                  .light-mode-text {
                    background-image: linear-gradient(to right, #000000 40%, #cbd5e1 50%, #000000 60%);
                  }
                `}} />
                <h1 className={`animated-status-text text-sm md:text-base font-extrabold uppercase tracking-widest drop-shadow-sm animate-in slide-in-from-top-4 fade-in duration-300 ${isDark ? 'dark-mode-text' : 'light-mode-text'}`}>
                  {status}
                </h1>
              </div>
            )}

            <div className="flex flex-wrap items-center justify-end gap-3 md:gap-4 w-full md:w-auto z-10">
              
              <button onClick={toggleTheme} className={`w-8 h-8 md:w-10 md:h-10 shrink-0 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-90 shadow-md border ${isDark ? 'bg-white/5 border-white/10 text-yellow-300 hover:bg-white/10' : 'bg-white border-slate-200 text-indigo-500 hover:bg-slate-50'}`} title="Đổi giao diện">
                {isDark ? '🌞' : '🌙'}
              </button>
              
              <button 
                onClick={handleRegisterEmail}
                className="group relative flex items-center h-9 md:h-10 px-3 md:px-4 rounded-xl bg-[#212121] hover:bg-black text-white text-[11px] md:text-xs font-extrabold cursor-pointer border-none transition-all duration-300 active:scale-95 shadow-md overflow-hidden"
              >
                <div className="absolute left-3 md:left-4 group-hover:left-1/2 group-hover:-translate-x-1/2 transition-all duration-500 flex items-center justify-center z-10">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="w-4 h-4 md:w-5 md:h-5 fill-[#9b9999] group-hover:fill-white transition-all duration-500 group-hover:scale-125">
                    <path d="M22 6C22 4.9 21.1 4 20 4H4C2.9 4 2 4.9 2 6V18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V6ZM20 6L12 11L4 6H20ZM20 18H4V8L12 13L20 8V18Z"></path>
                  </svg>
                </div>
                <span className="pl-5 md:pl-7 opacity-100 group-hover:opacity-0 transition-opacity duration-300 whitespace-nowrap relative z-0">Email OTP</span>
              </button>

              <button 
                onClick={handleRegisterFaceID}
                className="group relative flex items-center h-9 md:h-10 px-3 md:px-4 rounded-xl bg-[#212121] hover:bg-black text-white text-[11px] md:text-xs font-extrabold cursor-pointer border-none transition-all duration-300 active:scale-95 shadow-md overflow-hidden"
              >
                <div className="absolute left-3 md:left-4 group-hover:left-1/2 group-hover:-translate-x-1/2 transition-all duration-500 flex items-center justify-center z-10">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="w-4 h-4 md:w-5 md:h-5 fill-[#9b9999] group-hover:fill-white transition-all duration-500 group-hover:scale-125">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zM8.5 9.5a1.5 1.5 0 100-3 1.5 1.5 0 000 3zm7 0a1.5 1.5 0 100-3 1.5 1.5 0 000 3zM12 17.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z"></path>
                  </svg>
                </div>
                <span className="pl-5 md:pl-7 opacity-100 group-hover:opacity-0 transition-opacity duration-300 whitespace-nowrap relative z-0">FaceID</span>
              </button>

              <button 
                onClick={onLock}
                className="group relative flex items-center h-9 md:h-10 px-3 md:px-4 rounded-xl bg-[#2b101c] hover:bg-[#400010] text-rose-300 text-[11px] md:text-xs font-extrabold cursor-pointer border-none transition-all duration-300 active:scale-95 shadow-md overflow-hidden"
              >
                <div className="absolute left-3 md:left-4 group-hover:left-1/2 group-hover:-translate-x-1/2 transition-all duration-500 flex items-center justify-center z-10">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="w-4 h-4 md:w-5 md:h-5 fill-[#fca5a5] group-hover:fill-rose-500 transition-all duration-500 group-hover:scale-125">
                    <path d="M22,15.04C22,17.23 20.24,19 18.07,19H5.93C3.76,19 2,17.23 2,15.04C2,13.07 3.43,11.44 5.31,11.14C5.28,11 5.27,10.86 5.27,10.71C5.27,9.33 6.38,8.2 7.76,8.2C8.37,8.2 8.94,8.43 9.37,8.8C10.14,7.05 11.13,5.44 13.91,5.44C17.28,5.44 18.87,8.06 18.87,10.83C18.87,10.94 18.87,11.06 18.86,11.17C20.65,11.54 22,13.13 22,15.04Z"></path>
                  </svg>
                </div>
                <span className="pl-5 md:pl-7 opacity-100 group-hover:opacity-0 transition-opacity duration-300 whitespace-nowrap text-rose-400 relative z-0">Khóa Két</span>
              </button>
            </div>
          </header>

          <div className="flex-1 overflow-y-auto px-4 md:px-8 pb-12 custom-scrollbar overflow-x-hidden">
            {activeTab === 'all' && !searchQuery && (
              <div className="mb-8 md:mb-12 mt-6 md:mt-8 animate-in slide-in-from-bottom-4 duration-500 max-w-full">
                <div className="flex items-end justify-between mb-4">
                  <div className="w-full">
                    <h2 className={`text-2xl md:text-3xl font-extrabold flex flex-wrap items-center gap-3 ${textHeading}`}>
                      Vùng an toàn 
                      <span className={`text-[10px] px-2 py-1 rounded font-bold uppercase tracking-widest border ${isDark ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30' : 'bg-indigo-100 text-indigo-600 border-indigo-200'}`}>Riêng tư</span>
                    </h2>
                    <p className={`text-xs md:text-sm mt-2 ${textSub}`}>Chào bạn, những điều đẹp nhất đôi khi chỉ cần mình bạn biết. ✨</p>
                  </div>
                </div>

                <div className={`mt-4 md:mt-6 w-full py-8 md:h-[300px] md:py-0 border-[2px] border-dashed rounded-2xl md:rounded-3xl flex flex-col items-center justify-center text-center relative group transition-all duration-300 backdrop-blur-md ${uploadBox}`}>
                  <div className="w-12 h-12 md:w-16 md:h-16 mb-2 md:mb-4 relative drop-shadow-xl">
                    <span className="text-4xl md:text-5xl absolute inset-0 flex items-center justify-center group-hover:scale-125 group-hover:-translate-y-3 transition-all duration-500">☁️</span>
                  </div>
                  <h3 className={`text-lg md:text-xl font-bold mb-1 md:mb-2 ${textHeading}`}>Upload Ở Đây </h3>
                  <p className={`text-[10px] md:text-xs mb-4 md:mb-6 px-4 ${textSub}`}>Ấn nút chọn ảnh từ máy để lưu trữ khoảnh khắc của bạn.</p>
                  
                  <div className="flex flex-col items-center gap-3 w-full px-4">
                    <button onClick={() => fileInputRef.current?.click()} className="px-6 md:px-8 py-2.5 md:py-3 w-full max-w-[200px] bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs md:text-sm font-bold rounded-xl shadow-lg hover:shadow-indigo-500/50 transition-all flex items-center justify-center gap-2">
                      + Chọn ảnh từ máy
                    </button>
                    <input type="file" accept="image/*,video/*" multiple ref={fileInputRef} onChange={handleFileSelect} className="hidden" />
                    
                    <div className="flex flex-col items-center gap-2 mt-2 w-full">
                      <label className={`flex items-center gap-2 cursor-pointer text-[10px] md:text-xs font-semibold hover:opacity-80 transition-opacity ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                        <input type="checkbox" checked={isUploadPrivate} onChange={(e) => setIsUploadPrivate(e.target.checked)} className="rounded border-slate-400 text-rose-500 focus:ring-0 transition-all w-3.5 h-3.5 md:w-4 md:h-4"/>
                        Bảo vệ cấp 2 (Tuyệt Mật)
                      </label>
                      {isUploadPrivate && (
                        <input type="password" placeholder="Mật khẩu khóa ảnh..." value={uploadLevel2Key} onChange={(e) => setUploadLevel2Key(e.target.value)} className={`w-full max-w-[200px] rounded-lg px-3 py-2 text-[10px] md:text-xs outline-none focus:ring-2 focus:ring-rose-400 transition-all ${isDark ? 'bg-black/60 border border-slate-600 text-white' : 'bg-white border border-slate-300 text-slate-800 shadow-inner'}`}/>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {selectedFiles.length > 0 && (
              <div className="sticky top-4 z-30 mb-8 flex items-center justify-between p-4 bg-indigo-600/90 backdrop-blur-xl border border-indigo-400/50 rounded-2xl shadow-[0_10px_40px_rgba(79,70,229,0.3)] animate-in slide-in-from-top-4">
                <div className="flex items-center gap-4">
                  <span className="text-sm font-bold text-white">Đã chọn: {selectedFiles.length} mục</span>
                  <button onClick={() => setSelectedFiles([])} className="text-xs bg-white/20 hover:bg-white/30 active:scale-95 text-white px-4 py-2 rounded-lg transition-all font-semibold">Hủy chọn</button>
                </div>
                <div className="flex items-center gap-2">
                  {activeTab === 'trash' ? (
                    <>
                      <button onClick={handleBatchRestore} className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-white text-xs font-bold rounded-xl shadow-lg transition-all">♻️ Khôi phục</button>
                      <button onClick={handleBatchDelete} className="px-5 py-2 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white text-xs font-bold rounded-xl shadow-lg transition-all">☠️ Tiêu hủy</button>
                    </>
                  ) : (
                    <>
                      <button onClick={() => setShowColMenuFor('batch')} className="px-5 py-2 bg-white/20 hover:bg-white/30 active:scale-95 text-white text-xs font-bold rounded-xl shadow-lg transition-all">➕ Thêm vào BST</button>
                      <button onClick={handleBatchDownload} className="px-5 py-2 bg-blue-500 hover:bg-blue-400 active:scale-95 text-white text-xs font-bold rounded-xl shadow-lg transition-all">⬇️ Tải xuống</button>
                      <button onClick={handleBatchDelete} className="px-5 py-2 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white text-xs font-bold rounded-xl shadow-lg transition-all">🗑️ Xóa</button>
                    </>
                  )}
                </div>
              </div>
            )}

            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 mt-8 gap-4">
              <h2 className={`text-2xl font-extrabold uppercase tracking-wider ${textHeading}`}>
                {searchQuery ? `Tìm kiếm: "${searchQuery}"` : activeTab === 'all' ? 'Kho báu của bạn' : activeTab === 'favorites' ? 'Mục Yêu Thích' : activeTab === 'trash' ? 'Thùng Rác' : `Bộ Sưu Tập: ${activeTab}`}
              </h2>
              {activeTab !== 'all' && activeTab !== 'favorites' && activeTab !== 'trash' && !searchQuery && (
                <button onClick={() => setActiveTab('all')} className="px-5 py-2.5 bg-indigo-500 hover:bg-indigo-600 active:scale-95 text-white text-sm font-bold rounded-xl shadow-lg transition-all">
                  + Về Kho lấy thêm ảnh
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
              {displayImages.map((item, index) => {
                const displayName = aliases[item.filename] || item.filename.replace('.enc', '');
                const isSelected = selectedFiles.includes(item.filename);
                
                const isTapped = tappedCard === item.filename; 
                const showOverlay = isSelected || isTapped; 

                const isSelectable = !item.is_private || !!item.src;

                return (
                <div 
                  key={index} 
                  className={`group relative aspect-[4/3] rounded-[1.2rem] overflow-hidden cursor-pointer transition-all duration-300 shadow-lg hover:shadow-2xl ${cardBg} ${isSelected ? 'ring-4 ring-indigo-500 scale-[0.98]' : 'lg:hover:-translate-y-1'}`}
                  onClick={() => {
                     if (selectedFiles.length > 0) {
                       if (isSelectable) {
                          toggleSelectFile(item.filename);
                       }
                     } else {
                       if (item.src) setViewingImage(item.src);
                     }
                  }}
                >
                  
                  <div className="absolute top-3 left-3 z-20 pointer-events-none opacity-90 transition-opacity">
                    {isVideoFile(item) ? (
                      <span className="px-2.5 py-1 bg-black/70 backdrop-blur-md rounded-md border border-white/20 text-white text-[10px] font-extrabold flex items-center gap-1.5 shadow-lg">▶️ VIDEO</span>
                    ) : (
                      <span className="px-2.5 py-1 bg-black/70 backdrop-blur-md rounded-md border border-white/20 text-white text-[10px] font-extrabold flex items-center gap-1.5 shadow-lg">🖼️ ẢNH</span>
                    )}
                  </div>

                  <button 
                    className="absolute top-3 right-3 z-30 w-8 h-8 flex items-center justify-center bg-black/50 backdrop-blur-md rounded-full border border-white/20 text-white md:opacity-0 md:group-hover:opacity-100 transition-opacity active:scale-90"
                    onClick={(e) => {
                      e.stopPropagation(); 
                      setTappedCard(isTapped ? null : item.filename); 
                    }}
                  >
                    ⋮
                  </button>

                  <div className="w-full h-full absolute inset-0">
                    {item.thumb ? (
                      <img src={item.thumb} alt="thumb" className="w-full h-full object-cover blur-xl scale-125 lg:group-hover:scale-150 transition-transform duration-700" />
                    ) : item.src ? (
                      item.src.startsWith('data:video') ? (
                        <video src={item.src} className="w-full h-full object-cover lg:group-hover:scale-110 transition-transform duration-700" />
                      ) : (
                        <img src={item.src} alt="media" className="w-full h-full object-cover lg:group-hover:scale-110 transition-transform duration-700" />
                      )
                    ) : (
                      <div className={`w-full h-full flex flex-col items-center justify-center text-[10px] uppercase tracking-widest font-black ${isDark ? 'bg-[#13161E] text-slate-500' : 'bg-slate-200 text-slate-400'}`}>
                        {item.is_private ? (
                          <>
                            <span className="text-4xl mb-2 opacity-30 drop-shadow-md">🎬</span>
                            <span>Video Đã Khóa</span>
                          </>
                        ) : (
                          <span className="animate-pulse">Đang tải...</span>
                        )}
                      </div>
                    )}
                  </div>

                  <div 
                    className={`absolute inset-0 bg-gradient-to-t from-black/95 via-black/40 to-black/80 transition-opacity duration-300 flex flex-col justify-between p-4 z-20 ${showOverlay ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none lg:group-hover:opacity-100 lg:group-hover:pointer-events-auto'}`}
                    onClick={(e) => {
                        if (isTapped) {
                           e.stopPropagation();
                           setTappedCard(null);
                        }
                    }}
                  >
                    <div className="flex justify-between items-start mt-8">
                      
                      {isSelectable ? (
                        <div 
                           className="w-8 h-8 flex items-start justify-start cursor-pointer z-30"
                           onClick={(e) => {
                              e.stopPropagation(); 
                              toggleSelectFile(item.filename); 
                           }}
                        >
                          <input 
                            type="checkbox" 
                            checked={isSelected}
                            readOnly
                            className="w-5 h-5 rounded border-2 border-white/80 text-indigo-500 focus:ring-0 bg-black/50 cursor-pointer shadow-lg checked:border-indigo-500 transition-all hover:scale-110 active:scale-95 pointer-events-none"
                          />
                        </div>
                      ) : (
                        <div className="w-8 h-8"></div>
                      )}
                      
                      <div className="grid grid-cols-2 gap-3 mt-2 mr-1 relative z-30">
                        <svg width="0" height="0" className="absolute">
                          <defs>
                            <clipPath id="squircleClip" clipPathUnits="objectBoundingBox">
                              <path d="M 0,0.5 C 0,0 0,0 0.5,0 S 1,0 1,0.5 1,1 0.5,1 0,1 0,0.5"></path>
                            </clipPath>
                          </defs>
                        </svg>

                        {isSelectable && (
                          <>
                            {activeTab !== 'all' && activeTab !== 'favorites' && activeTab !== 'trash' ? (
                              <button 
                                onClick={(e) => { e.stopPropagation(); handleRemoveFromCollection(activeTab, item.filename); }} 
                                style={{ clipPath: 'url(#squircleClip)' }}
                                className="w-9 h-9 bg-gradient-to-br from-rose-500 to-rose-800 flex items-center justify-center shadow-lg border border-rose-400/50 cursor-pointer transform transition-all duration-300 ease-out hover:scale-110 hover:-translate-y-1 hover:shadow-2xl" 
                                title="Rút khỏi Bộ sưu tập này"
                              >
                                <span className="text-white text-xs drop-shadow-md font-bold">➖</span>
                              </button>
                            ) : activeTab === 'all' ? (
                              <button 
                                onClick={(e) => { e.stopPropagation(); setShowColMenuFor(item.filename); }} 
                                style={{ clipPath: 'url(#squircleClip)' }}
                                className="w-9 h-9 bg-gradient-to-br from-indigo-500 to-indigo-800 flex items-center justify-center shadow-lg border border-indigo-400/50 cursor-pointer transform transition-all duration-300 ease-out hover:scale-110 hover:-translate-y-1 hover:shadow-2xl" 
                                title="Thêm vào Bộ sưu tập"
                              >
                                <span className="text-white text-xs drop-shadow-md">📁</span>
                              </button>
                            ) : null}

                            {item.is_private && item.src && activeTab !== 'trash' && (
                               <button 
                                 onClick={(e) => { e.stopPropagation(); if(window.confirm("Bỏ lớp bảo vệ và chuyển file này thành CÔNG KHAI?")) handleChangePrivacy(item, false); }} 
                                 style={{ clipPath: 'url(#squircleClip)' }}
                                 className="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-800 flex items-center justify-center shadow-lg border border-blue-400/50 cursor-pointer transform transition-all duration-300 ease-out hover:scale-110 hover:-translate-y-1 hover:shadow-2xl" 
                                 title="Bỏ mã hóa, chuyển thành Công Khai"
                               >
                                 <span className="text-white text-xs drop-shadow-md">🌍</span>
                               </button>
                            )}

                            {activeTab !== 'trash' && (
                              <button 
                                onClick={(e) => { e.stopPropagation(); toggleFavorite(item.filename); }} 
                                style={{ clipPath: 'url(#squircleClip)' }}
                                className={`w-9 h-9 bg-gradient-to-br flex items-center justify-center shadow-lg border cursor-pointer transform transition-all duration-300 ease-out hover:scale-110 hover:-translate-y-1 hover:shadow-2xl ${favorites.includes(item.filename) ? 'from-rose-500 to-rose-700 border-rose-400/50' : 'from-gray-700 to-gray-900 border-gray-500/50'}`}
                                title={favorites.includes(item.filename) ? "Bỏ yêu thích" : "Thêm vào yêu thích"}
                              >
                                <span className={`text-xs drop-shadow-md transition-transform duration-300 ${favorites.includes(item.filename) ? 'scale-110' : ''}`}>
                                  {favorites.includes(item.filename) ? '❤️' : '🤍'}
                                </span>
                              </button>
                            )}
                            
                            {activeTab !== 'trash' ? (
                              <button 
                                onClick={(e) => { e.stopPropagation(); handleSoftDelete(item.filename); }} 
                                style={{ clipPath: 'url(#squircleClip)' }}
                                className="w-9 h-9 bg-gradient-to-br from-red-600 to-red-900 flex items-center justify-center shadow-lg border border-red-500/50 cursor-pointer transform transition-all duration-300 ease-out hover:scale-110 hover:-translate-y-1 hover:shadow-2xl" 
                                title="Chuyển vào thùng rác"
                              >
                                <span className="text-white text-xs drop-shadow-md">🗑️</span>
                              </button>
                            ) : (
                              <>
                                <button 
                                  onClick={(e) => { e.stopPropagation(); handleRestore(item.filename); }} 
                                  style={{ clipPath: 'url(#squircleClip)' }}
                                  className="w-9 h-9 bg-gradient-to-br from-emerald-500 to-emerald-800 flex items-center justify-center shadow-lg border border-emerald-400/50 cursor-pointer transform transition-all duration-300 ease-out hover:scale-110 hover:-translate-y-1 hover:shadow-2xl" 
                                  title="Khôi phục"
                                >
                                  <span className="text-white text-xs drop-shadow-md">♻️</span>
                                </button>
                                <button 
                                  onClick={(e) => { e.stopPropagation(); handleHardDelete(item.filename); }} 
                                  style={{ clipPath: 'url(#squircleClip)' }}
                                  className="w-9 h-9 bg-gradient-to-br from-red-700 to-red-950 flex items-center justify-center shadow-lg border border-red-600/50 cursor-pointer transform transition-all duration-300 ease-out hover:scale-110 hover:-translate-y-1 hover:shadow-2xl" 
                                  title="Xóa vĩnh viễn"
                                >
                                  <span className="text-white text-xs drop-shadow-md font-bold">☠️</span>
                                </button>
                              </>
                            )}
                          </>
                        )}
                        
                        {activeTab !== 'trash' && (
                          <button 
                            onClick={async (e) => { 
                              e.stopPropagation(); 
                              if(item.is_private && item.src) {
                                 handleRelockSingle(item.filename);
                              } else if (item.is_private && !item.src) {
                                 const pwd = await askPrompt("Nhập mật khẩu cấp 2 để MỞ KHÓA TẠM THỜI:", true);
                                 if(pwd) handleUnlockSinglePrivate(item.filename, pwd);
                              } else {
                                 const pwd = await askPrompt("Nhập mật khẩu để KHÓA TUYỆT MẬT ảnh này:", true);
                                 if (pwd) handleChangePrivacy(item, true, pwd);
                              }
                            }} 
                            style={{ clipPath: 'url(#squircleClip)' }}
                            className={`w-9 h-9 bg-gradient-to-br flex items-center justify-center shadow-lg border cursor-pointer transform transition-all duration-300 ease-out hover:scale-110 hover:-translate-y-1 hover:shadow-2xl ${item.is_private ? (item.src ? 'from-emerald-500 to-emerald-700 border-emerald-400/50' : 'from-rose-500 to-rose-800 border-rose-400/50') : 'from-gray-700 to-gray-900 border-gray-600/50'}`}
                            title={item.is_private ? (item.src ? "Đang mở. Bấm để khóa lại ngay" : "Bấm để nhập mật khẩu xem ảnh") : "Bấm để khóa tuyệt mật cấp 2"}
                          >
                            <span className="text-white text-xs drop-shadow-md">
                              {item.is_private ? (item.src ? '🔓' : '🔒') : '🔓'}
                            </span>
                          </button>
                        )}
                      </div>
                    </div>

                    <div className={`mt-auto transform transition-transform duration-300 ${showOverlay ? 'translate-y-0' : 'translate-y-3 lg:group-hover:translate-y-0'}`}>
                      <div className="flex items-center justify-between gap-2 mb-1.5">
                        <p className="text-white text-sm font-bold truncate leading-tight drop-shadow-lg flex-1" title={displayName}>{displayName}</p>
                        <button onClick={async (e) => { e.stopPropagation(); await handleRename(item.filename, displayName); }} className="text-[10px] bg-white/20 hover:bg-white/40 text-white px-2 py-1 rounded backdrop-blur-md opacity-50 hover:opacity-100 transition-all active:scale-90 font-bold" title="Đổi tên hiển thị">✏️ Đổi Tên</button>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded flex items-center gap-1 text-[10px] font-extrabold uppercase tracking-wider shadow-md pointer-events-none ${item.is_private ? 'bg-rose-500 text-white' : 'bg-slate-600/90 text-slate-200'}`}>
                          {item.is_private ? '🔒 Tuyệt mật' : '📁 Công khai'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )})}
            </div>
            
            {displayImages.length === 0 && (
              <div className="text-center py-40 flex flex-col items-center">
                <span className="text-6xl mb-6 opacity-40 animate-bounce">📭</span>
                <p className={`text-base font-medium ${textSub}`}>{searchQuery ? 'Không tìm thấy kỷ niệm nào khớp tên.' : 'Két sắt đang trống trải.'}</p>
              </div>
            )}
          </div>
        </main>
      </div>

      {showColMenuFor && (
        <div className="fixed inset-0 z-[10000] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in" onClick={() => setShowColMenuFor(null)}>
          <div className="bg-[#13161E] border border-white/10 rounded-3xl p-8 w-full max-w-sm shadow-2xl scale-100 transition-transform" onClick={e => e.stopPropagation()}>
            <h3 className="text-white font-extrabold mb-6 text-xl flex items-center gap-3"><span>📁</span> Chọn Bộ Sưu Tập</h3>
            {Object.keys(collections).length === 0 ? (
              <p className="text-sm text-slate-400 mb-8 bg-white/5 p-4 rounded-xl text-center">Bạn chưa có bộ sưu tập nào.</p>
            ) : (
              <div className="space-y-3 max-h-60 overflow-y-auto custom-scrollbar pr-2 mb-8">
                {Object.keys(collections).map(col => (
                  <button key={col} onClick={() => executeAddToCollection(col)} className="w-full text-left px-5 py-4 rounded-2xl bg-white/5 hover:bg-indigo-500 hover:shadow-lg active:scale-95 text-slate-300 hover:text-white transition-all flex justify-between items-center group">
                    <span className="truncate font-bold text-base">{col}</span>
                    <span className="text-xs bg-black/30 px-3 py-1 rounded-lg opacity-50 group-hover:opacity-100 transition-opacity font-mono">{collections[col].length}</span>
                  </button>
                ))}
              </div>
            )}
            <div className="flex justify-end gap-4 pt-6 border-t border-white/10">
              <button onClick={() => setShowColMenuFor(null)} className="px-5 py-2.5 rounded-xl text-sm font-semibold text-slate-400 hover:bg-white/10 active:scale-95 transition-all">Hủy</button>
              <button onClick={async () => { setShowColMenuFor(null); await handleCreateCollection(); }} className="px-6 py-2.5 rounded-xl text-sm bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold active:scale-95 transition-all shadow-lg shadow-indigo-500/30">+ Tạo Mới</button>
            </div>
          </div>
        </div>
      )}

      {promptData.isOpen && (
        <div className="fixed inset-0 z-[99999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in zoom-in-95 duration-200">
          <div className="bg-[#fff] border-4 border-black rounded-none p-8 w-full max-w-md shadow-[10px_10px_0_#4a90e2] transition-all relative overflow-hidden">
            
            <div className="relative font-mono mt-8 mb-8">
              <input
                type={promptData.isPassword && !showPasswordToggle ? "password" : "text"}
                value={promptInput}
                onChange={(e) => setPromptInput(e.target.value)}
                placeholder="TYPE HERE"
                className="w-full p-4 text-[18px] font-bold text-black bg-white border-4 border-black outline-none rounded-none shadow-[5px_5px_0_#000] focus:border-[#4a90e2] focus:shadow-[5px_5px_0_#4a90e2] transition-all duration-300 placeholder:text-gray-500 focus:placeholder:text-transparent relative z-10"
                style={{
                  animation: promptInput ? 'none' : 'focus-pulse 4s cubic-bezier(0.25, 0.8, 0.25, 1) infinite'
                }}
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    promptData.resolve?.(promptInput);
                    setPromptData(p => ({ ...p, isOpen: false }));
                  }
                }}
              />
              
              <label className="absolute -left-[3px] -top-[35px] text-[14px] font-bold text-white bg-black px-[10px] py-[5px] -rotate-1 z-20 transition-all duration-300 peer-focus:rotate-0 peer-focus:scale-105 peer-focus:bg-[#4a90e2] uppercase">
                {promptData.message}
              </label>

              <style dangerouslySetInnerHTML={{__html: `
                @keyframes focus-pulse {
                  0%, 100% { border-color: #000; box-shadow: 5px 5px 0 #000; }
                  50% { border-color: #4a90e2; box-shadow: 5px 5px 0 #4a90e2; }
                }
                
                input:focus {
                  animation: focus-pulse 4s cubic-bezier(0.25, 0.8, 0.25, 1) infinite, glitch 0.3s cubic-bezier(0.25, 0.8, 0.25, 1) infinite;
                }
                
                @keyframes glitch {
                  0% { transform: translate(0); }
                  20% { transform: translate(-2px, 2px); }
                  40% { transform: translate(-2px, -2px); }
                  60% { transform: translate(2px, 2px); }
                  80% { transform: translate(2px, -2px); }
                  100% { transform: translate(0); }
                }
                
                input:focus::before {
                  content: ""; position: absolute; top: 0; left: 0; width: 100%; height: 100%;
                  background: black; z-index: -2; clip-path: inset(0 100% 0 0);
                  animation: glitch-slice 4s steps(2, end) infinite;
                }
                
                @keyframes glitch-slice {
                  0% { clip-path: inset(0 100% 0 0); }
                  10% { clip-path: inset(0 5% 0 0); }
                  20% { clip-path: inset(0 80% 0 0); }
                  30% { clip-path: inset(0 10% 0 0); }
                  40% { clip-path: inset(0 50% 0 0); }
                  50% { clip-path: inset(0 30% 0 0); }
                  60% { clip-path: inset(0 70% 0 0); }
                  70% { clip-path: inset(0 15% 0 0); }
                  80% { clip-path: inset(0 90% 0 0); }
                  90% { clip-path: inset(0 5% 0 0); }
                  100% { clip-path: inset(0 100% 0 0); }
                }
              `}} />

              {promptData.isPassword && (
                <button
                  onClick={() => setShowPasswordToggle(!showPasswordToggle)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-black hover:text-[#4a90e2] text-xl z-20 transition-colors"
                  title={showPasswordToggle ? "Ẩn mật khẩu" : "Hiện mật khẩu"}
                >
                  {showPasswordToggle ? '👁️' : '🙈'}
                </button>
              )}
            </div>

            <div className="flex justify-end gap-4 mt-6">
              <button
                onClick={() => {
                  promptData.resolve?.(null);
                  setPromptData(p => ({ ...p, isOpen: false }));
                }}
                className="font-mono px-6 py-3 bg-white text-black border-4 border-black font-bold uppercase transition-transform hover:-translate-y-1 hover:shadow-[4px_4px_0_#000] active:translate-y-1 active:shadow-none"
              >
                Hủy
              </button>
              <button
                onClick={() => {
                  promptData.resolve?.(promptInput);
                  setPromptData(p => ({ ...p, isOpen: false }));
                }}
                className="font-mono px-6 py-3 bg-[#4a90e2] text-white border-4 border-black font-bold uppercase transition-transform hover:-translate-y-1 hover:shadow-[4px_4px_0_#000] active:translate-y-1 active:shadow-none"
              >
                Xác nhận
              </button>
            </div>
          </div>
        </div>
      )}

      {viewingImage && (
        <div className="fixed inset-0 bg-black/95 z-[9999] flex items-center justify-center p-8 backdrop-blur-3xl animate-in fade-in duration-200" onClick={() => setViewingImage(null)}>
          <button onClick={() => setViewingImage(null)} className="absolute top-6 right-8 text-slate-400 hover:text-white text-5xl font-light hover:scale-125 active:scale-90 transition-all">&times;</button>
          {viewingImage.startsWith('data:video') ? (
            <video src={viewingImage} controls autoPlay className="max-w-full max-h-full rounded-2xl shadow-[0_0_100px_rgba(0,0,0,0.8)] border border-white/10 animate-in zoom-in-95 duration-300" onClick={e => e.stopPropagation()} />
          ) : (
            <img src={viewingImage} alt="Full size" className="max-w-full max-h-full object-contain rounded-2xl shadow-[0_0_100px_rgba(0,0,0,0.8)] border border-white/10 animate-in zoom-in-95 duration-300" onClick={e => e.stopPropagation()} />
          )}
        </div>
      )}

      <style dangerouslySetInnerHTML={{__html: `
        .custom-scrollbar::-webkit-scrollbar { width: 8px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(100,116,139,0.3); border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(100,116,139,0.5); }
      `}} />
    </div>
  );
}