# ⚙️ Hush - Backend (Secure Vault API)

Hệ thống máy chủ xử lý logic trung tâm cho ứng dụng két sắt Hush. Backend được thiết kế theo nguyên tắc "Zero-Knowledge" đối với nội dung file (chỉ nhận và lưu trữ blob đã mã hóa), tập trung xử lý xác thực, định tuyến OTP và quản lý trạng thái thiết bị.

## ✨ Tính năng nổi bật
* **Quản lý Passkeys:** Liên kết chuỗi băm `wallet_address` (SHA-256) với thiết bị duy nhất và email bảo mật thông qua PostgreSQL.
* **Xác thực WebAuthn (Server-side):** Tạo cấu hình challenge và verify thông tin sinh trắc học gửi từ Frontend.
* **Hệ thống gửi Email OTP Bypass:** Tích hợp Google Apps Script Webhook để phát mã OTP 6 số qua Gmail, tránh bị block SMTP trên các nền tảng cloud server.
* **Quản lý Storage trung gian:** Cầu nối upload/delete file vào bucket của Supabase Storage.

## 🛠 Công nghệ sử dụng
* **Framework:** FastAPI (Python)
* **Database & Storage:** Supabase (PostgreSQL)
* **Authentication:** `webauthn` (Python Library)
* **Mail Service:** HTTP Webhook (GAS)

## 🚀 Hướng dẫn cài đặt

1. Tạo môi trường ảo và cài đặt thư viện:
   ```bash
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
   *(Lưu ý: Trên Windows, lệnh kích hoạt môi trường ảo là `venv\Scripts\activate`)*

2. Tạo file `.env` ở thư mục gốc và thêm:
   ```ini
   SUPABASE_URL=your_supabase_url
   SUPABASE_KEY=your_supabase_service_key
   DELETE_PASSWORD=your_system_delete_password
   ```

3. Khởi chạy Server:
   ```bash
   uvicorn main:app --reload
   ```
   *API Docs (Swagger UI) sẽ có mặt tại: [http://localhost:8000/docs](http://localhost:8000/docs)*
